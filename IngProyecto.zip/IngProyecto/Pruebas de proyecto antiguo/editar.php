<?php 
include ("conexion.php");

?>

<!DOCTYPE html>

<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Editar</title>
    <link href="css/style.css" rel="stylesheet">
</head>
<body>
    <?php
        if(isset($_POST['editarEmpleado'])){
            $IDEmp = $_POST['IDEmp'];
            $NombreEmp =$_POST['NombreEmp'];
            $CorreoEmp= $_POST['CorreoEmp'];
            $PuestoEmp= $_POST['PuestoEmp'];

            
$sql ="update templeados set NombreEmp='".$NombreEmp."',CorreoEmp='".$CorreoEmp."',PuestoEmp='".$PuestoEmp."'where IDEmp ='".$IDEmp."'";
            $resultado=mysqli_query($conexion,$sql);
            if($resultado){
                echo "<script language ='JavaScript'> 
                alert('Se actualizó el producto correctamente.'); 
                location.assign('index.html');
                </script>";

            }else{
                echo "<script language ='JavaScript'> 
                alert('No se actualizó el producto.'); 
                location.assign('index.html'); 
                </script>";
            }
            mysqli_close($conexion);

        }else{

            $IDEmp =$_GET['IDEmp'];
            $sql="select * from templeados where IDEmp ='".$IDEmp ."'";
            $resultado=mysqli_query($conexion,$sql);

            $filas=mysqli_fetch_assoc($resultado);
            
            $NombreEmp= $filas["NombreEmp"];
            $CorreoEmp= $filas["CorreoEmp"];
            $PuestoEmp= $filas["PuestoEmp"];

            mysqli_close($conexion);        

    ?>
    <h1>Editar Empleado</h1>
    <form action="<?=$_SERVER['PHP_SELF']?>" method="POST">

    <label>ID del Empleado: <?php echo $IDEmp; ?></label><br><br>
    <label>Nombre: </label>
    <input type="text" name="NombreEmp" value="<?php echo $NombreEmp; ?>"> <br>

    <label>Correo: </label>
    <input type="text" name="CorreoEmp" value="<?php echo $CorreoEmp; ?>"><br>

    <label>Puesto: </label>
    <input type="text" name="PuestoEmp" value="<?php echo $PuestoEmp; ?>"><br>

    <input type="hidden" name ="IDEmp" value ="<?php echo $IDEmp; ?>">

    <input type="submit" name ="editarEmpleado" value="Actualizar">
    <a href="PruebasEmpleados.php">Regresar</a>
    </form>
    <?php 
}?>
</body>
</html>