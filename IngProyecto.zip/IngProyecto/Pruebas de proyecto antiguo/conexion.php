<?php
$server = "localhost";
$user = "root";
$pass = "";
$db = "cafeteriabd";

$conexion = new mysqli($server, $user, $pass, $db);
?>