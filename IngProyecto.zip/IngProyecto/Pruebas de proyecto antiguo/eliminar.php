<!-- definicion ventajas desventajas y aplicaciones disparadores -->
<?php 
include ("conexion.php");
$IDEmp=$_GET['IDEmp'];

$sql="delete from templeados where IDEmp ='".$IDEmp."'";
$resultado=mysqli_query($conexion,$sql);
if($resultado){
    echo "<script language ='JavaScript'> 
    alert('Se eliminó el empleado correctamente.'); 
    location.assign('PruebasEmpleados.php'); 
    </script>";

}else{
    echo "<script language ='JavaScript'> 
    alert('NO se eliminó el empleado.'); 
    location.assign('PruebasEmpleados.php'); 
    </script>";
}
?>
