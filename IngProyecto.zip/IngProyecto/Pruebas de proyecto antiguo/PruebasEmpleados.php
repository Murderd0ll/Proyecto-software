<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <title>CAFETERIA DEL TEC</title>
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <meta content="Free Website Template" name="keywords">
    <meta content="Free Website Template" name="description">

    <script type="text/javascript">
        function confirmar(){
            return confirm('¿Desea eliminar? No se podrán revertir los cambios.');
        }
        </script>

   <!-- Fuentes  -->
   <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.10.0/css/all.min.css" rel="stylesheet">

   <!-- Librerias Stylesheet -->
   <link href="lib/owlcarousel/assets/owl.carousel.min.css" rel="stylesheet">
   <link href="lib/tempusdominus/css/tempusdominus-bootstrap-4.min.css" rel="stylesheet" />

   <!-- Hoja de estilo Stylesheet -->
   <link href="css/style.css" rel="stylesheet">
</head>

<body>
    <!-- Inicio de la barra de navegación -->
    <div class="container-fluid p-0 nav-bar">
        <nav class="navbar navbar-expand-lg bg-none navbar-dark py-3">
            <button type="button" class="navbar-toggler" data-toggle="collapse" data-target="#navbarCollapse">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse justify-content-between" id="navbarCollapse">
                <div class="navbar-nav ml-auto p-4">
                    <a href="index.html" class="nav-item nav-link">Inicio</a>                    
                    <a href="PruebasEmpleados.php" class="nav-item nav-link active">Empleados</a>
                    <a href="Pedidos.php" class="nav-item nav-link">Pedidos</a>
                    <a href="menu.html" class="nav-item nav-link">Menu</a>
                </div>
            </div>
        </nav>
    </div>
    <!-- fin  de la barra de navegación -->


    <!-- Inicio del encabezado de página -->
    <div class="container-fluid page-header mb-5 position-relative overlay-bottom">
        <div class="d-flex flex-column align-items-center justify-content-center pt-0 pt-lg-5" style="min-height: 400px">
            <h1 style="font-size: 70px;" class="display-4 mb-3 mt-0 mt-lg-5 text-white text-uppercase">Empleados</h1>
        </div>
    </div>
    <!-- fin del encabezado de página -->
    <?php 
    include("conexion.php");
    $sql = "select * from templeados";
    $resultado = mysqli_query($conexion, $sql);
    ?>

    
    <a href="ingresar.php">Nuevo empleado</a><br></br>
    <table>
        <thead>
            <tr>
                <th>ID</th>
                <th>Nombre</th> 
                <th>Correo</th>              
                <th>Puesto</th>
                <th>Opciones</th>
            </tr>
        </thead>
        <tbody>

            <?php
                while($filas = mysqli_fetch_assoc($resultado))
                {
    
            ?>

            <tr>
                <td> <?php echo $filas['IDEmp'] ?> </td>                
                <td> <?php echo $filas['NombreEmp'] ?> </td>
                <td> <?php echo $filas['CorreoEmp'] ?> </td>
                <td> <?php echo $filas['PuestoEmp'] ?> </td>
                <td>
                    
                    <?php echo "<a href='editar.php?IDEmp=".$filas['IDEmp']. "'>Editar</a>"; ?>
                     |
                    <?php echo "<a href='eliminar.php?IDEmp=".$filas['IDEmp']. "' onclick='return confirmar()'>Eliminar</a>"; ?>
                </td>
            </tr>

            <?php
                }
            ?>

        </tbody>
    </table>
    <?php 
        mysqli_close($conexion);
    ?>



    <!-- Volver al inicio -->
    <a href="#" class="btn btn-lg btn-primary btn-lg-square back-to-top"><i class="fa fa-angle-double-up"></i></a>


    <!-- Librerias JavaScript  -->
    <script src="https://code.jquery.com/jquery-3.4.1.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.bundle.min.js"></script>
    <script src="lib/easing/easing.min.js"></script>
    <script src="lib/waypoints/waypoints.min.js"></script>
    <script src="lib/owlcarousel/owl.carousel.min.js"></script>
    <script src="lib/tempusdominus/js/moment.min.js"></script>
    <script src="lib/tempusdominus/js/moment-timezone.min.js"></script>
    <script src="lib/tempusdominus/js/tempusdominus-bootstrap-4.min.js"></script>

    <!-- conexión Javascript File -->
    <script src="mail/jqBootstrapValidation.min.js"></script>
    <script src="mail/contact.js"></script>

    <!-- Plantilla Javascript -->
    <script src="js/main.js"></script>
</body>

</html>