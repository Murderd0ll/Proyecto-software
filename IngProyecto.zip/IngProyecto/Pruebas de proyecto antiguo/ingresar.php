<!--Agregar empleados-->
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Agregar nuevo empleado</title>
    <link href="css/style.css" rel="stylesheet">
</head>
<body>

    <?php 
        if(isset($_POST['agregarEmpleado'])){

            $NombreEmp = $_POST['NombreEmp'];
            $CorreoEmp = $_POST['CorreoEmp'];            
            $PuestoEmp = $_POST['PuestoEmp'];

            include("conexion.php");
            $sql="insert into templeados(NombreEmp,CorreoEmp,PuestoEmp) 
            values ('".$NombreEmp."','".$CorreoEmp."','".$PuestoEmp."')";
            $resultado = mysqli_query($conexion, $sql);

            if($resultado){
                echo" <script language ='JavaScript'>
                alert('Se ha agregado un nuevo empleado a la BDD.');
                location.assign('index.html');
                </script>";

            }else{
                echo"<script language ='JavaScript'>
                alert('Error, NO se ha agregado un nuevo empleado a la BDD.');
                location.assign('index.html');
                </script>";

            }
            mysqli_close($conexion);
        }
        else{
    ?>

    <h1>Agregar nuevo empleado</h1>
    <form action="<?=$_SERVER['PHP_SELF']?>" method ="post">
    
    <label>Nombre: </label>
    <input type="text" name ="NombreEmp"><br>
    <label>Correo: </label>
    <input type="text" name ="CorreoEmp"><br>
    <label>Puesto: </label>
    <input type="text" name ="PuestoEmp"><br>
    <input type="submit" name ="agregarEmpleado" value="Agregar">
    <a href="index.html">Regresar</a>
    </form>
    <?php
            }
    ?>


</body>
</html>