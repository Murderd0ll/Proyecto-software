<!--Pedidos -->
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Administrar pedidos</title>
    <script type="text/javascript">
        function confirmar(){
            return confirm('¿Desea eliminar? No se podrán revertir los cambios.');
        }
        </script>
    <link href="css/style.css" rel="stylesheet">
</head>
<body>

    <?php 
        if(isset($_POST['AddPedido'])){

            $ProductoPedido = $_POST['ProductoPedido'];
            $Cantidad = $_POST['Cantidad'];            
            $Comentarios = $_POST['Comentarios'];

            include("conexion.php");
            $sql="insert into tpedidos(ProductoPedido,Cantidad,Comentarios) 
            values ('".$ProductoPedido."','".$Cantidad."','".$Comentarios."')";
            $resultado = mysqli_query($conexion, $sql);

            if($resultado){
                echo" <script language ='JavaScript'>
                alert('Se ha agregado un nuevo pedido a la BDD.');
                location.assign('Pedidos.php');
                </script>";

            }else{
                echo"<script language ='JavaScript'>
                alert('Error, NO se ha agregado un nuevo pedido a la BDD.');
                location.assign('Pedidos.php');
                </script>";

            }
            mysqli_close($conexion);
        }
        else{
    ?>

    <h1>Agregar nuevo pedido</h1>
    <form action="<?=$_SERVER['PHP_SELF']?>" method ="post">
    
    <label>Producto: </label>
    <input type="text" name ="ProductoPedido"><br>
    <label>Cantidad: </label>
    <input type="text" name ="Cantidad"><br>
    <label>Comentarios: </label>
    <input type="text" name ="Comentarios"><br>
    <input type="submit" name ="AddPedido" value="Agregar">
    <br><br>
    <a href="index.html">Regresar a la página principal</a>
    </form>
    <?php
            }
    ?>
<br><br>

    <?php 
    include("conexion.php");
    $sql = "select * from tpedidos";
    $resultado = mysqli_query($conexion, $sql);
    ?>

    <table>
        <thead>
            <tr>
                <th>ID</th>
                <th>Producto</th> 
                <th>Cantidad</th>              
                <th>Comentarios</th>
                <th>Opciones</th>
            </tr>
        </thead>
        <tbody>

            <?php
                while($filas = mysqli_fetch_assoc($resultado))
                {
    
            ?>

            <tr>
                <td> <?php echo $filas['IDPedido'] ?> </td>                
                <td> <?php echo $filas['ProductoPedido'] ?> </td>
                <td> <?php echo $filas['Cantidad'] ?> </td>
                <td> <?php echo $filas['Comentarios'] ?> </td>
                <td>
                    
                    <?php echo "<a href='EditPedidos.php?IDPedido=".$filas['IDPedido']. "'>Editar</a>"; ?>
                     |
                    <?php echo "<a href='EliminarPedidos.php?IDPedido=".$filas['IDPedido']. "' onclick='return confirmar()'>Eliminar</a>"; ?>
                </td>
            </tr>

            <?php
                }
            ?>

        </tbody>
    </table>
    <?php 
        mysqli_close($conexion);
    ?>


</body>
</html>