<?php 
include ("conexion.php");

?>

<!DOCTYPE html>

<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Editar</title>
    <link href="css/style.css" rel="stylesheet">
</head>
<body>
    <?php
        if(isset($_POST['EditPedidos'])){
            $IDPedido = $_POST['IDPedido'];
            $ProductoPedido =$_POST['ProductoPedido'];
            $Cantidad= $_POST['Cantidad'];
            $Comentarios= $_POST['Comentarios'];

            
$sql ="update tpedidos set ProductoPedido='".$ProductoPedido."',Cantidad='".$Cantidad."',Comentarios='".$Comentarios."'where IDPedido ='".$IDPedido."'";
            $resultado=mysqli_query($conexion,$sql);
            if($resultado){
                echo "<script language ='JavaScript'> 
                alert('Se actualizó el pedido correctamente.'); 
                location.assign('Pedidos.php');
                </script>";

            }else{
                echo "<script language ='JavaScript'> 
                alert('No se actualizó el pedido.'); 
                location.assign('Pedidos.php'); 
                </script>";
            }
            mysqli_close($conexion);

        }else{

            $IDPedido =$_GET['IDPedido'];
            $sql="select * from tpedidos, templeados where IDPedido ='".$IDPedido ."'";
            $resultado=mysqli_query($conexion,$sql);

            $filas=mysqli_fetch_assoc($resultado);
            
            $ProductoPedido= $filas["ProductoPedido"];
            $Cantidad= $filas["Cantidad"];
            $Comentarios= $filas["Comentarios"];

            mysqli_close($conexion);        

    ?>
    <h1>Editar pedido</h1>
    <form action="<?=$_SERVER['PHP_SELF']?>" method="POST">

    <label>ID del pedido: <?php echo $IDPedido; ?></label><br><br>
    <label>Producto: </label>
    <input type="text" name="ProductoPedido" value="<?php echo $ProductoPedido; ?>"> <br>

    <label>Cantidad: </label>
    <input type="text" name="Cantidad" value="<?php echo $Cantidad; ?>"><br>

    <label>Comentarios: </label>
    <input type="text" name="Comentarios" value="<?php echo $Comentarios; ?>"><br>

    <input type="hidden" name ="IDPedido" value ="<?php echo $IDPedido; ?>">

    <input type="submit" name ="EditPedidos" value="Actualizar">
    <a href="Pedidos.php">Regresar</a>
    </form>
    <?php 
}?>
</body>
</html>