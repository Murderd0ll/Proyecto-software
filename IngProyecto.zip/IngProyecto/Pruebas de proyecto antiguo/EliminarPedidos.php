<?php 
include ("conexion.php");
$IDPedido=$_GET['IDPedido'];

$sql="delete from tpedidos where IDPedido ='".$IDPedido."'";
$resultado=mysqli_query($conexion,$sql);
if($resultado){
    echo "<script language ='JavaScript'> 
    alert('Se eliminó el pedido correctamente.'); 
    location.assign('Pedidos.php'); 
    </script>";

}else{
    echo "<script language ='JavaScript'> 
    alert('NO se eliminó el pedido.'); 
    location.assign('Pedidos.php'); 
    </script>";
}
?>
